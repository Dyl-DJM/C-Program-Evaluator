#include <stdio.h>

int main(int argc, char* argv[]){
  int a = argv[0];
  int b = argv[1];

  printf("La somme de %d et %d vaut %d\n", a, b, a+b);
  return 0;
}